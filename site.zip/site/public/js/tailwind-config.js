tailwind.config = {
    theme: {
        extend: {
            screens: {
                'md': '896px',
            }
        }
    }
}
